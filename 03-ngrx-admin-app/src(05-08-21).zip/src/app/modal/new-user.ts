export class Register {
    constructor(
        public id = '',
        public name = '',
        public age = '',
        public gender = '',
        public email = '',
        public company = '',
        public role = ''
    ){}
}
