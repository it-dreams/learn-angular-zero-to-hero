import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Register } from '../../../../modal/new-user';
import {
  FormGroup,
  FormBuilder,
  Validators,
  AbstractControl,
  FormControl,
} from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { IUser } from 'src/app/modal/user';
import { Store } from '@ngrx/store';
import { CreateUserSuccess } from 'src/app/store/actions/user.actions';

@Component({
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./new-user.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class NewUserComponent implements OnInit {
  register = new Register();

  registerForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private router: Router,
    private route: ActivatedRoute,
    private store: Store
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    this.registerForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      gender: ['', Validators.required],
      company: '',
      emailGroup: this.fb.group(
        {
          email: ['', [Validators.required, Validators.email]],
          confirmEmail: ['', [Validators.required]],
        },
        { validator: this.emailMatcher }
      ),
      age: '',
    });
  }

  addUser() {
    const users: any = {
      name: this.registerForm.value.name,
      gender: this.registerForm.value.gender,
      company: this.registerForm.value.company,
      email: this.registerForm.value.email,
      age: this.registerForm.value.age,
    };
    this.store.dispatch(new CreateUserSuccess(users));
    console.log(users);
    this.Reset();
  }

  // testData() {
  //   this.registerForm.patchValue({
  //     username: 'Rahul',
  //     gender: 'male',
  //     company: '',
  //     email: 'rahul@gmail.com',
  //     age: '32'
  //   })
  // }

  Reset() {
    this.registerForm.reset();
  }

  emailMatcher(ac: AbstractControl): { [key: string]: boolean } | null {
    const emailControl = ac.get('email');
    const confirmControl = ac.get('confirmEmail');
    if (emailControl.pristine || confirmControl.pristine) {
      return null;
    }
    if (emailControl.value === confirmControl.value) {
      return null;
    }
    return { match: true };
  }
}
