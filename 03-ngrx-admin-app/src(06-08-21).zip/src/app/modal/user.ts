export interface IUser {
    "id": number,
    "name": string,
    "age": number,
    "gender": string,
    "email": string,
    "company": string,
    "role": string
}
