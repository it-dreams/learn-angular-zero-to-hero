import { UsersFilterPipe } from './users-filter.pipe';

describe('UsersFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new UsersFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
